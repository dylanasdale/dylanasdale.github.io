# AI Manual Companion Pack

A field kit from Asdale Dynamics: new prompts, cheat sheets, checklists, and copy-paste workflows.

**This is original material.** It is not a reprint, excerpt, or condensed edition of *The Massive AI Manual*.

When a prompt says `[SOMETHING IN BRACKETS]`, replace the brackets with your details.

## What this is

This Companion Pack is a field kit: prompts you can paste, cheat sheets you can keep open, checklists you can print, and multi-step workflows that tell you in what order to use them. It is original material written for people who already have (or do not need) a long manual. It is not a reprint, excerpt, or condensed edition of The Massive AI Manual, and it is not a substitute for that book.

## How to use it

Skim the cheat sheets once. Pick one workflow that matches the week you are actually having. When a prompt says [SOMETHING IN BRACKETS], replace the brackets with your details. Save the prompts that work in your own library. Leave the rest until you need them. You do not owe this pack a cover-to-cover read.

## A note on tools

The prompts are written to work in everyday assistants. They do not depend on a particular brand, paid plan, or button label. Where a workflow mentions a workspace or an automation tool, you can carry the same idea into whatever you already use.

## A note on judgment

These are tools, not a deputy who can take responsibility for you. Check facts before you repeat them. Do not paste secrets. Do not send a message you have not read. If a result would matter a lot if it were wrong, slow down and use the evaluation cheat sheet.

## Contents

1. Cheat sheets
2. Prompt library (60 prompts in 10 categories)
3. Checklists
4. Copy-paste workflows
5. License

## 1. Cheat sheets

### Anatomy of a prompt that actually steers the work

- **Job.** One sentence for what 'done' looks like. If you cannot say it, you are not ready to prompt yet.
- **Context.** Only the facts the assistant cannot know: audience, constraints, tools, and the current state.
- **Examples.** One short sample of the voice or format you want beats a paragraph of adjectives.
- **Limits.** What not to do, what not to invent, and what to ask instead of guessing.
- **Output shape.** Ask for a table, memo, checklist, or email — not 'a thoughtful response.'
- **Check.** Tell it how you will judge the answer (accuracy, brevity, tone, sources).

*A handy order: job, context, examples, limits, output shape, check. You can skip a part; do not skip the job.*

### Output-format recipes you can paste

- **One-page memo.** Ask for: recommendation, why, risks, next step, and what would change your mind. Cap the length.
- **Table.** Name the columns. Ask for one row per item and a final 'so what' line under the table.
- **Rubric.** Ask it to score 1-5 on named criteria and to quote evidence for each score.
- **Decision log.** Date, decision, owner, options considered, and the first review date.
- **Red / yellow / green.** Useful for status. Require a one-line reason for any color that is not green.
- **JSON or bullets, not both.** If a person will read it, use prose or a table. If a tool will read it, ask for JSON and name the keys.

*Name the shape up front. 'Use whatever format you think is best' is how you get a shapeless essay.*

### Rewrite modes (same facts, different job)

- **Shorter.** Same meaning, fewer words. Keep caveats unless you explicitly park them in a list underneath.
- **Kinder.** Lower the heat. Do not add praise the original did not earn.
- **Firmer.** Make the ask or the boundary unmistakable. Do not add blame.
- **Clearer.** Shorter sentences, concrete nouns, one idea per sentence.
- **More formal.** Still human. Formal is not the same as stiff or legalistic.
- **Speakable.** Something you could say out loud in a meeting without wincing.

*Always say 'keep the facts the same.' Otherwise a rewrite will smuggle in new claims.*

### How to evaluate an answer in three minutes

- **Did it do the job?.** Look at your definition of done, not at how confident the prose sounds.
- **Did it invent?.** Scan for numbers, citations, product names, quotes, and dates you did not provide.
- **Can you use it?.** If you still have to rebuild the structure, the answer was a vibe, not a deliverable.
- **Is the tone sendable?.** Read one paragraph out loud. Would you put your name under it?
- **What is still missing?.** Name the gap and ask for only that, instead of 'try again, better.'

*A confident tone is not evidence. Treat it as typography.*

### Draft vs. reason vs. look up

- **Draft.** When you already know the facts and need a first version: emails, outlines, rewrite passes.
- **Reason.** When you need tradeoffs, a plan, or a critique. Ask it to show the criteria, not just the conclusion.
- **Look up.** When a fact must be true in the world. Use a tool or a source you can open. Do not let a draft invent the fact.
- **Combine carefully.** It is fine to draft from a source-checked brief. It is not fine to let the draft grow new facts.

*If the job is factual, start with look-up or your own notes, then draft.*

### Privacy, paste hygiene, and common sense

- **Do not paste.** Passwords, session cookies, one-time codes, full identification numbers, financial account numbers, private health records, or other people's secrets.
- **Describe, don't dump.** You can usually describe the shape of a situation instead of pasting the raw document.
- **Placeholder it.** Replace names and account IDs with ROLE_A, CLIENT_2, ACCT_X, then map them back yourself.
- **Check the room.** Know whether a chat is used to train a model, stored, or shared with a team. That changes what you paste.
- **Your accounts.** Do not ask an assistant to 'just log in as me.' Grant the least access that still does the job, and revoke it later.

*If a leak would genuinely hurt, keep it out of the chat. No prompt is worth that.*

## 2. Prompt library

### Clarify the work before you start

#### Name the real job

**When to use.** You feel busy in the chat but are not sure what 'done' looks like.

```
I need help with this: [PASTE THE TASK OR QUESTION].

Before you draft anything, do four things:
1. Restate the job in one sentence.
2. List what 'done' looks like in concrete terms.
3. List what you would need from me to do this well, including any missing facts.
4. Offer two possible approaches and recommend one, with a reason.

Do not start the actual work until I confirm the job and the approach.
```

**Watch for.** If the assistant jumps straight into a draft, stop and rerun this. Confirmation is the point.

#### Shrink a vague request

**When to use.** A request is broad enough to waste an hour (for example, 'help me get organized').

```
Here is a vague request: [PASTE IT].

Turn it into three tighter versions:
- A 15-minute version
- A 45-minute version
- A half-day version

For each, give the outcome, the inputs I must provide, and the first step. Then tell me which version you recommend if I only have [TIME AVAILABLE].
```

**Watch for.** Pick a version on purpose. A vague request will expand to fill the whole evening.

#### Audience and stakes

**When to use.** The output will be seen by someone else, or it has a deadline or a cost if it is wrong.

```
I am creating [DELIVERABLE] for [AUDIENCE]. The stakes are [WHAT HAPPENS IF THIS IS WEAK OR WRONG]. The tone should be [TONE]. Constraints: [LENGTH, FORMAT, THINGS TO AVOID].

Ask me up to five clarifying questions, then write a one-paragraph brief I can approve before you produce the work.
```

**Watch for.** High-stakes work should not start with 'write the email.' Start with a brief.

#### What not to do

**When to use.** You keep getting long answers that ignore your limits.

```
Help me with [TASK]. Non-negotiable limits:
- Do not [LIMIT 1]
- Do not [LIMIT 2]
- Stay inside [TOOL, BUDGET, TIME, OR FORMAT]
- If a limit blocks a good solution, say so and offer a workaround I can approve.

After you acknowledge the limits, give me the plan in five lines or fewer.
```

**Watch for.** Limits belong at the top, not buried in a postscript.

#### One question first

**When to use.** You are about to dump a pile of context and hope the model figures it out.

```
I want help with [SHORT DESCRIPTION]. You may ask me one question — the single question whose answer would most improve the result. Then stop and wait.
```

**Watch for.** One good question beats ten polite ones. If you already know the answer, skip this.

#### Define 'good enough'

**When to use.** You are polishing past the point of usefulness.

```
The task is [TASK]. I need a good-enough version I can use by [DEADLINE], not a masterpiece.

Tell me: what would a good-enough result include, what would you skip, and what quality checks are still worth doing? Then produce only the good-enough version.
```

**Watch for.** Say the deadline and the bar out loud. Otherwise the assistant will overbuild.

### Thinking and decisions

#### Decision memo, one page

**When to use.** You have to choose and want the tradeoffs in one place, not a chat-length essay.

```
Help me decide: [DECISION]. Options I already see: [OPTION A], [OPTION B], [OPTION C or 'suggest a third'].
Context: [FACTS, CONSTRAINTS, VALUES].

Write a one-page memo with:
- The decision in one sentence (your recommendation)
- The criteria you used
- A short table of options vs. criteria
- The strongest objection to your recommendation, and your reply
- The first next step if I accept it
- The information that would change the recommendation

Label anything you inferred vs. anything I stated.
```

**Watch for.** A memo you can reread tomorrow is more useful than a confident paragraph.

#### Pre-mortem

**When to use.** You are about to commit time, money, or reputation to a plan.

```
Assume it is six months from now and this plan failed: [DESCRIBE THE PLAN].

Write a pre-mortem: the five most plausible reasons it failed, early warning signs I could watch for, and one cheap change I could make now to reduce each risk. Be specific. Do not give generic advice like 'communicate better.'
```

**Watch for.** If every risk is vague, push once: 'make each failure mode observable.'

#### What would have to be true

**When to use.** You like an idea and need to test it, not just cheer for it.

```
I am attracted to this idea: [IDEA].

List what would have to be true for this to be a good idea. Mark each item as: already true, unknown, or probably false. For every unknown, give me the fastest way to learn it this week.
```

**Watch for.** This prompt is for testing, not for talking yourself into the idea.

#### Two-advisor split

**When to use.** You want pushback and a plan, and one voice keeps blurring both.

```
Play two advisors on this situation: [SITUATION].

Advisor 1 is cautious and looks for hidden costs.
Advisor 2 is practical and looks for a smallest useful move.

Each advisor gets a short brief. Then they reply to each other once. End with a joint recommendation I can act on today, even if they still disagree on the long term.
```

**Watch for.** If both advisors sound the same, say so and ask them to disagree on purpose.

#### Reversible vs. irreversible

**When to use.** You are stalling on a choice that may not deserve the delay.

```
Here is a choice I am sitting on: [CHOICE].

Classify it as reversible, costly-to-reverse, or truly hard to undo, and explain why. If it is reversible, propose a small experiment I can run in [TIME FRAME]. If it is hard to undo, list the two facts I should get before deciding.
```

**Watch for.** Many 'big decisions' are reversible. Name which kind you are in.

#### Values conflict

**When to use.** Two good goals are colliding (speed vs. quality, privacy vs. convenience, rest vs. money).

```
I have a values conflict: [VALUE A] is bumping into [VALUE B] in this situation: [SITUATION].

Do not tell me which value is 'correct.' Help me design a choice that honors a minimum standard for each, and show me what I would be giving up. End with two honorable options and the cost of each.
```

**Watch for.** If the assistant moralizes, rewind: you asked for honorable options, not a lecture.

### Research and checking work

#### Source-checked brief

**When to use.** You need a briefing and cannot afford invented citations.

```
Brief me on [TOPIC] for a reader who needs to [PURPOSE].

Rules:
- Separate 'established,' 'disputed,' and 'unknown.'
- For every non-obvious claim, give a source I can open (title, publisher or site, and date if you have it).
- If you are not sure a source exists, say 'I cannot verify this' instead of inventing one.
- End with three questions I should still answer myself.

Length: about [LENGTH].
```

**Watch for.** Open at least one source. A tidy brief with a fake link is worse than a shorter honest one.

#### Claim audit

**When to use.** You have a draft, a post, or a report and want the weak claims marked.

```
Audit the claims in this text:

[PASTE]

For each factual or numerical claim, tag it as: supported in the text, needs a source, outdated risk, or overstated. Quote the claim, say why you tagged it, and tell me how I could verify it in ten minutes or less. Do not rewrite the piece until I ask.
```

**Watch for.** Use this before you publish, send, or reuse a number.

#### Compare three sources

**When to use.** You have a few links or quotes that do not quite agree.

```
I am looking at these sources on [TOPIC]:
1. [SOURCE OR PASTE]
2. [SOURCE OR PASTE]
3. [SOURCE OR PASTE]

Make a comparison: where they agree, where they disagree, what each one might be optimizing for, and what I should not conclude yet. Then give me a cautious summary in ten lines.
```

**Watch for.** Pay attention to dates and definitions. Many 'disagreements' are different questions.

#### Number hygiene

**When to use.** A number showed up (a price, a percentage, a deadline, a statistic) and you are tempted to trust it.

```
This number appeared in my work: [NUMBER AND CONTEXT].

Help me interrogate it. What does it actually measure? What might be missing from the denominator? What time period? What would a misleading version of this number look like? What question should I ask before I repeat it?
```

**Watch for.** If the assistant cannot explain the number in plain language, do not repeat it.

#### Counter-brief

**When to use.** You already have a conclusion and need someone to try to knock it down.

```
My current conclusion is: [CONCLUSION]. Here is my reasoning and evidence: [PASTE].

Write a counter-brief: the strongest fair case against this conclusion, the evidence I may be overweighting, and what would make you accept my conclusion after all. Stay civil and specific.
```

**Watch for.** Ask for a fair case, not a snarky one. You want to get sturdier, not win a debate with a chatbot.

#### Reading notes that survive

**When to use.** You read something useful and know you will forget it by next week.

```
Here is what I read:
[PASTE OR NOTES]

Make standing notes I can file:
- One-sentence gist
- Three points worth keeping
- Terms I should not misuse
- What this does *not* prove
- One action or question it suggests for my work: [YOUR WORK CONTEXT]
```

**Watch for.** Notes that include 'what this does not prove' age better than notes that only praise the piece.

### Writing in a human voice

#### Voice sample, then draft

**When to use.** You want a draft that sounds like you, not like a template.

```
Here are three short samples of my writing:

[PASTE 3 SAMPLES]

Describe my voice in six bullets (sentence length, favored words, things I never say, humor, formality, how I handle disagreement). Then draft [DELIVERABLE] about [TOPIC] in that voice. After the draft, list any places you drifted from the samples.
```

**Watch for.** Bad samples in, generic voice out. Pick samples you are proud of.

#### Explain like I have to use it

**When to use.** You understand a topic just well enough to be dangerous, and have to explain it to someone else.

```
Explain [TOPIC] so I can actually use the explanation. Assume I am smart and busy, not new to the world. Use one concrete example from [MY CONTEXT]. Avoid pep talk and avoid jargon unless you define it in the same sentence. End with a five-line version I could say out loud.
```

**Watch for.** If you cannot say the five-line version out loud, the longer version is not ready either.

#### From bullets to a piece

**When to use.** You have notes and need a first draft, not a reshuffling of the bullets.

```
Here are my notes:
[PASTE]

Turn these into a first draft of [FORMAT] for [AUDIENCE]. Keep my meaning. You may reorder for clarity, but put any new claims you added in [brackets] so I can approve or cut them. Aim for [LENGTH].
```

**Watch for.** Bracketed additions keep the assistant honest about what it invented.

#### Cut the shine

**When to use.** A draft sounds like marketing copy even though you asked for plain language.

```
Rewrite this so a careful human would actually send it. Remove filler, false urgency, and compliment sandwiches. Keep the substance. If a sentence is only there to sound 'professional,' cut it.

[PASTE]
```

**Watch for.** Read the rewrite out loud. If you would be embarrassed to say it, it still has shine on it.

#### Two tones, same facts

**When to use.** You are not sure whether to be warmer, shorter, or more formal.

```
Using only the facts in this text, write two versions of [DELIVERABLE]: one [TONE A] and one [TONE B]. Do not add facts. Afterward, tell me what each version will make the reader feel, and which one you would send if you were me, given this relationship: [RELATIONSHIP].

[PASTE]
```

**Watch for.** Choose the tone for the relationship, not for the model’s default cheerfulness.

#### Outline I can argue with

**When to use.** You do not want a full draft yet; you want to fight with the structure first.

```
Make an outline for [PIECE] about [TOPIC] for [AUDIENCE]. Each section gets one sentence that states the point, plus a note on the evidence or example I will need. Flag any section that is doing two jobs and should be split. Do not write the piece.
```

**Watch for.** Arguing with an outline is cheaper than arguing with a finished draft.

### Editing and tightening

#### Line edit with a light touch

**When to use.** The draft is close and you want it cleaner, not rewritten in someone else's style.

```
Line-edit this draft. Keep my voice and structure unless a change is needed for clarity or accuracy. Use comments in brackets for bigger issues; do not silently rewrite my meaning.

Return: (1) the edited draft, (2) a short list of the changes that mattered, (3) any claim that still needs a source.

[PASTE]
```

**Watch for.** If the 'edit' changes your point of view, it was a rewrite. Ask for a lighter pass.

#### Half the length, same meaning

**When to use.** Something is twice as long as the reader will tolerate.

```
Cut this to about half the length without losing the meaning or the important caveats. If a caveat must go, list it underneath so I can decide whether to put it back.

[PASTE]
```

**Watch for.** Watch the caveats. Cuts love to delete the sentence that kept you honest.

#### Ambiguity hunt

**When to use.** The reader could take a key sentence two ways, and that would be a problem.

```
Read this as a slightly ungenerous reader. List every sentence that could reasonably be read two ways, quote it, give both readings, and offer a tighter sentence for each.

[PASTE]
```

**Watch for.** Especially useful for anything with money, dates, owners, or promises.

#### First-sentence test

**When to use.** The opening is soft and the real point is in paragraph three.

```
Here is a draft:
[PASTE]

Suggest five possible opening sentences that state the point clearly. Then show me the draft with your favorite opening applied and the old throat-clearing removed.
```

**Watch for.** If the first sentence could sit in front of almost any piece, it is not doing its job.

#### Consistency pass

**When to use.** Names, dates, buttons, or terms drift over a long draft.

```
Do a consistency pass only. Check names, titles, dates, numbers, product or button names, and hyphenation. List inconsistencies in a table: item, first version, later version, suggested standard. Do not do a full rewrite.

[PASTE]
```

**Watch for.** Keep this pass separate so the model does not 'improve' sentences you already like.

#### Kind but clear critique

**When to use.** You want feedback on a draft without getting a fake rave or a pile-on.

```
Critique this draft as a skilled, kind editor. Give: one sentence on what it is trying to do, three strengths worth keeping, three specific problems (quote the text), and a suggested order of revision. Do not rewrite it unless I ask.

[PASTE]
```

**Watch for.** Ask for quoted problems. Vague critique ('make it punchier') is not actionable.

### Emails and difficult conversations

#### Purpose, then the email

**When to use.** You are about to write a message that could go sideways.

```
I need to write to [PERSON / ROLE] about [SITUATION]. My purpose is [PURPOSE: inform, request, decline, repair, set a boundary, confirm]. The relationship is [CONTEXT]. I want them to be able to [SPECIFIC NEXT STEP].

Draft the email in a clear, human voice, under [LENGTH]. Give me a subject line, and then list the risk in this email and how the draft tries to reduce it.
```

**Watch for.** Name the purpose first. A 'quick update' that is actually a request will be misread.

#### The decline

**When to use.** You need to say no (or not now) without burning the relationship or writing a chapter.

```
Help me decline this: [REQUEST]. I want to keep the relationship [WARM / PROFESSIONAL / DISTANT]. I can or cannot offer [ALTERNATIVE]. Draft a short no that is direct, unexcusing, and civil. Then give me a slightly warmer variant. Do not invent a fake scheduling conflict.
```

**Watch for.** A clean no is kinder than a soft maybe you do not mean.

#### Repair after a miss

**When to use.** Something slipped: a late reply, a mistake, a missed meeting, a sharp message.

```
I need to repair this: [WHAT HAPPENED]. What I know I owe them: [ACKNOWLEDGMENT]. What I can actually do next: [NEXT STEP]. What I should not promise: [LIMIT].

Draft a short message that owns my part, states the next step, and does not over-apologize or explain myself into a hole.
```

**Watch for.** Do not let the assistant add promises you cannot keep.

#### Ask for something specific

**When to use.** You need a yes, a file, a decision, or a meeting, and your drafts dance around it.

```
Draft a request to [PERSON] for [SPECIFIC ASK]. Why it matters: [REASON]. Deadline: [DATE]. What I have already tried: [CONTEXT]. Make the ask in the first or second sentence. Offer a default option they can accept quickly, plus an easy way to decline or propose another option.
```

**Watch for.** If they could not forward your ask to someone else in one sentence, it is not specific enough.

#### Meeting follow-up

**When to use.** The meeting ended and you need a record people will actually recognize.

```
Using these notes, write a follow-up message with: decisions, owners, dates, open questions, and the next meeting or checkpoint if one was mentioned. Use only what is in the notes. Put anything you had to infer in [brackets].

[NOTES]
```

**Watch for.** Send this the same day if you can. Memory and goodwill both fade.

#### Boundary, calmly

**When to use.** Someone is asking for more access, time, or work than you can give.

```
I need to set this boundary: [BOUNDARY]. The pattern I am seeing: [PATTERN]. What I am willing to do: [YES]. What I am not willing to do: [NO]. Draft a calm message with no sarcasm and no over-explaining. Then warn me about one way this could be misread and how I might pre-empt that.
```

**Watch for.** A good boundary names a yes and a no. Only a no feels like a wall; only a yes is not a boundary.

### Plans and projects

#### From goal to a two-week plan

**When to use.** You have a goal and a fog of tasks.

```
Goal: [GOAL]. Time I can really give it: [HOURS PER WEEK] for the next two weeks. Constraints: [CONSTRAINTS]. Definition of progress: [WHAT WOULD COUNT].

Give me a two-week plan with a weekly outcome, three tasks per week at most, and a 'if this slips' rule. Put any task that depends on someone else in its own list.
```

**Watch for.** If the plan has twelve priorities, it is not a plan yet.

#### Work breakdown with owners

**When to use.** A project lives in your head as one blob called 'finish X.'

```
Break this project into a work breakdown I can run: [PROJECT]. For each task: outcome, suggested owner (or 'me'), estimated time as S/M/L, and dependencies. Star the tasks that actually reduce risk early. End with a proposed first week.
```

**Watch for.** Estimates as S/M/L are enough at this stage. Fake hour counts create false precision.

#### Scope trim

**When to use.** The project has grown and the date has not.

```
Here is the current scope:
[PASTE]
The hard date is [DATE]. The must-have outcome is [OUTCOME].

Propose a trimmed scope that still delivers the must-have, a parking lot for the rest, and the conversation I should have with [STAKEHOLDER] about what is moving.
```

**Watch for.** Trimming is a conversation, not just a list. The prompt gives you language for that talk.

#### Stuck project restart

**When to use.** Work has stalled and opening the file feels heavy.

```
This project is stuck: [PROJECT]. Last useful state: [WHAT WAS TRUE WHEN IT LAST MOVED]. What I am avoiding: [IF YOU KNOW]. I have [TIME] today.

Give me a restart plan for today only: a 10-minute entry task, a 40-minute meaningful task, and a shutdown note I can leave for tomorrow. Do not redesign the whole project unless I ask.
```

**Watch for.** Today-only restarts beat a shame-filled overhaul.

#### Risks, owners, triggers

**When to use.** You want a lightweight risk list, not a 40-row register no one will update.

```
For this project: [PROJECT], list up to seven real risks. For each: likelihood (H/M/L), impact (H/M/L), trigger I would actually notice, owner, and a first response that takes less than an hour to start. Skip theatrical risks.
```

**Watch for.** A risk without a trigger is just a worry. Make it observable.

#### Status note in ten lines

**When to use.** Someone reasonable asked 'where are we?' and you do not want a novel.

```
Using these raw notes, write a ten-line status update: goal, current state, what moved since last time, what's blocked, what's next, and any decision I need from the reader. No fluff.

[NOTES]
```

**Watch for.** If a line does not change what the reader will do, cut it.

### Meetings and notes

#### Agenda that earns the meeting

**When to use.** You are about to hold a meeting that might have been a message.

```
Help me design an agenda for a [LENGTH] meeting about [TOPIC] with [WHO]. Desired decisions: [DECISIONS]. Desired information: [INFO].

Give me: a one-sentence purpose, a timed agenda, pre-work I should send, and a recommendation — meet, delay, or replace with a message — with a reason.
```

**Watch for.** If the assistant cannot name a decision or a coordination problem, consider not meeting.

#### Notes to a decision log

**When to use.** You have messy notes and need a record of what was actually decided.

```
Turn these notes into: decisions (with owners and dates), actions, open questions, and parking-lot items. If a 'decision' in the notes is actually still fuzzy, mark it as unresolved instead of inventing certainty.

[NOTES]
```

**Watch for.** Fuzzy decisions marked as resolved will haunt you next week.

#### Prep in fifteen minutes

**When to use.** You have a call soon and a thin file.

```
I have a call with [WHO] in a short window, about [TOPIC]. Here is what I know:
[NOTES]

Give me a 15-minute prep pack: the likely goal of the call, five questions I should be ready to ask, three facts I should confirm, and a suggested opening line. Flag anything I still need and cannot invent.
```

**Watch for.** Do not let the pack invent a relationship history you did not provide.

#### Debrief for myself

**When to use.** The meeting is over and you want to learn, not just file notes.

```
Here is what happened: [NOTES OR MEMORY]. Help me debrief privately: what I was trying to do, what I think landed, what I would do differently, and one follow-up I should send today. Keep this for me, not as a message to the group.
```

**Watch for.** Private debriefs can be candid. Do not paste other people's sensitive comments into tools you do not trust.

#### Shared recap vs. private notes

**When to use.** You need a recap you can send, and a longer set of notes you should keep.

```
From these notes, produce two documents: (1) a short shared recap that is fair and sendable, and (2) private notes for me that include hunches, loose ends, and things I should not put in a group email. Label them clearly.

[NOTES]
```

**Watch for.** Never send the private layer by accident. Keep the labels obvious.

#### Extract owners without inventing them

**When to use.** The notes mention work, but not always who owns it.

```
Extract every action in these notes. If an owner or date is explicit, record it. If it is missing, write 'UNASSIGNED' or 'NO DATE' — do not guess. End with a list of questions I can use to close the gaps.

[NOTES]
```

**Watch for.** Guessing owners is how work falls on the most conscientious person in the room.

### Automations and repeatable systems

#### Should I automate this?

**When to use.** A task is annoying and you are tempted to build a machine for it.

```
Here is a task I keep repeating: [TASK]. Frequency: [HOW OFTEN]. Time each time: [TIME]. Error cost if it goes wrong: [COST]. Tools I already have: [TOOLS].

Tell me whether I should: keep doing it by hand, use a checklist, use a template, or automate it. If you recommend automation, sketch the smallest version, the trigger, the output, and the failure mode I must watch.
```

**Watch for.** The smallest version is the one you might actually finish. A 20-node workflow is not a first version.

#### Process to SOP

**When to use.** You can do a process, but it lives in your head.

```
I am going to describe a process I do. Turn it into a standard operating procedure a careful person could follow, including tools, decision points, and a short 'if this goes wrong' section. Flag any step I described sloppily and ask me to fill it in.

[DESCRIBE THE PROCESS]
```

**Watch for.** An SOP with fuzzy decision points will be ignored. Make the branches explicit.

#### Workflow sketch

**When to use.** You know the start and the end, but not the middle.

```
Sketch an automation for this:
Trigger: [WHAT STARTS IT]
Input: [WHAT ARRIVES]
Desired output: [WHAT SHOULD HAPPEN]
Tools I can use: [N8N, MAKE, EMAIL, SHEETS, NOTION, ETC.]

Give me a step-by-step sketch with nodes or modules, what could fail, and a manual backup. Do not pretend I have APIs or paid plans I did not mention.
```

**Watch for.** Ask the sketch to stay inside the tools you already have, or you will get a fantasy stack.

#### Failure modes for a flow

**When to use.** A draft automation exists and you want it to fail safely.

```
Here is a draft automation:
[DESCRIBE OR PASTE]

List failure modes: bad input, delayed input, duplicate runs, permission errors, silent success that did the wrong thing, and 'it ran while I was asleep.' For each, give a detection idea and a safe default (stop, queue, or notify).
```

**Watch for.** Silent wrong success is worse than a loud failure.

#### Checklist instead of a bot

**When to use.** You might not need software yet.

```
Turn this recurring work into a one-page checklist first: [TASK]. Include a start condition, the steps, a definition of done, and when I should consider automating later. Keep it printable.
```

**Watch for.** Many 'automations' are just a checklist you have not written down.

#### Handoff to my future self

**When to use.** You built something (a prompt, a sheet, a workflow) and will forget how it works.

```
Write a handoff note for this thing I built: [DESCRIPTION]. Include: what it is for, how to run it, what it needs, how I will know it worked, how I will know it broke, and the one thing I must not change carelessly. Keep it under a page.
```

**Watch for.** Future-you is a new teammate. Write for that person.

### Your personal command system

#### Weekly review questions

**When to use.** It is the end of the week and your tools are messy.

```
Here is a brain dump of my week:
[PASTE]

Run a weekly review: what moved, what slipped, what I am avoiding, what I should stop, what deserves a slot next week, and one system tweak (not a life overhaul). Give me a next-week list with at most five items.
```

**Watch for.** Cap the list at five or the review becomes another inbox.

#### Capture standard

**When to use.** Notes, screenshots, and 'I'll remember this' are landing everywhere.

```
Help me design a simple capture standard. Tools I already use: [TOOLS]. What I keep losing: [EXAMPLES]. Propose one inbox, one weekly processing ritual, and rules for what does not get captured. Keep it small enough that I will still do it on a tired day.
```

**Watch for.** One inbox is the feature. Five inboxes is how things vanish.

#### Role-based prompt library

**When to use.** You are writing one-off prompts and losing the good ones.

```
I do this kind of work often: [ROLES OR RECURRING JOBS]. Help me design a tiny prompt library: 8 named prompts, each with a purpose, the inputs I must paste, and a one-line success test. Do not write the full prompts yet — design the menu with me first.
```

**Watch for.** A menu you will use beats a 200-prompt graveyard.

#### What not to paste

**When to use.** You are about to drop a pile of text into a chat and have a low, uneasy feeling.

```
I am about to paste material into an assistant. Here is the kind of material: [DESCRIBE, DO NOT PASTE SECRETS]. Help me redact and substitute: what to remove, what to replace with placeholders, and how to still get a useful answer. Give me a pre-paste checklist.
```

**Watch for.** When in doubt, describe the shape of the data, not the data.

#### End-of-day shutdown

**When to use.** You stop working, but your brain does not.

```
Help me write a 5-minute shutdown checklist for days like this: [KIND OF WORKDAY]. It should include: park the active task, record the next starting step, park anything left in one inbox, and one sentence I can look at tomorrow morning.
```

**Watch for.** The sentence for tomorrow is the whole trick. Be kind and specific.

#### Teach-back after a new habit

**When to use.** You tried a new system for a week and need to keep only what worked.

```
For the past week I tried this system: [DESCRIPTION]. What actually happened: [NOTES]. Help me keep, drop, or shrink each part. Design a v2 that is easier to keep on a bad week, not a more impressive system for a perfect week.
```

**Watch for.** v2 should be smaller almost every time.

## 3. Checklists

### Ten-minute setup for a new chat

- [ ] State the job in one sentence, including what 'done' looks like.
- [ ] Add the audience, deadline, and constraints.
- [ ] Paste only the context the assistant cannot already know.
- [ ] Redact anything you would not want forwarded.
- [ ] Ask for a brief or a plan if the stakes are high, before a full draft.
- [ ] Name the output shape (memo, table, email, checklist).
- [ ] Say what it must not invent.
- [ ] Save any prompt that worked into your library the same day.

### Before you paste

- [ ] No passwords, codes, or recovery phrases.
- [ ] No full account or government ID numbers.
- [ ] No private documents you would not hand to a stranger at a coffee shop.
- [ ] Names and details of other people minimized unless they asked to be included.
- [ ] Placeholders stand in for anything sensitive.
- [ ] You know where this chat lives and who can see it.
- [ ] You could still get a useful answer from a description if the raw file stayed offline.

### Before you believe a fact or a number

- [ ] You can point to a source you can open, or to notes you already trusted.
- [ ] The date on the source still makes sense for this question.
- [ ] You know what the number is measuring, and over what period.
- [ ] A second source, or your own records, do not obviously contradict it.
- [ ] You are not repeating a rounded or cherry-picked version as if it were exact.
- [ ] If you cannot verify it in a few minutes, you label it as unverified or you cut it.

### Before you send AI-assisted writing

- [ ] The main point is in the first few lines.
- [ ] Every fact is one you accept responsibility for.
- [ ] Names, dates, and numbers were checked against the source, not just reread in the draft.
- [ ] The tone sounds like you, and you would say it out loud.
- [ ] Promises, dates, and dollar amounts are ones you can actually keep.
- [ ] Nothing confidential is in the outgoing message that should not be there.
- [ ] You, not the model, clicked send.

### Before you automate a task

- [ ] You have done the task by hand enough times to know the happy path.
- [ ] You wrote a checklist or SOP first.
- [ ] The trigger is unambiguous.
- [ ] The output has an owner who will notice if it is wrong.
- [ ] Failure is loud (a notification or a stopped run), not silent.
- [ ] Duplicates, delays, and bad input have a defined response.
- [ ] You have a manual backup that still works if the automation is off for a week.
- [ ] You are automating a stable task, not a process you still change every day.

### Weekly maintenance, thirty minutes

- [ ] Clear the single inbox to zero, or as close as you can honestly get.
- [ ] Close or park finished tasks. Do not let them pose as live work.
- [ ] Pick at most five commitments for the next week.
- [ ] Write down anything you are avoiding and give it a next physical step — or consciously drop it.
- [ ] Retire one prompt, rule, or automation that you are not using.
- [ ] Back up or export anything you would be sad to lose.
- [ ] Note one thing the system did well so you do not 'improve' it to death.

### Intake before a custom AI setup (for you, or for a client)

- [ ] What jobs should be easier in 30 days?
- [ ] What tools are already in daily use? Which ones are paid?
- [ ] Where does work currently get lost?
- [ ] What must never be connected or pasted into a third-party tool?
- [ ] Who has to be able to run this besides you?
- [ ] What does a good week look like, in plain language?
- [ ] What has already been tried, and why did it stall?
- [ ] What is the budget of time for upkeep after launch?

### Shipping a digital file to a customer

- [ ] The unzipped folder opens to a README or start-here file.
- [ ] File names are human and consistent.
- [ ] The license is in the folder.
- [ ] Links were clicked. Import files were opened once on a clean test.
- [ ] No leftover TODO notes, draft comments, or your private paths.
- [ ] The cover, title, and price match the listing.
- [ ] You can say in one sentence what the buyer can do in the first twenty minutes.

## 4. Copy-paste workflows

### From a messy idea to a one-page brief

**When to use.** Use when something is still a fog and you are tempted to start making slides or copy.

1. Dump the idea in whatever form you have — bullets, a rant, links, half-thoughts.
2. Run 'Name the real job' and 'Shrink a vague request.' Choose a 45-minute or half-day version.
3. Run 'Audience and stakes' and approve a one-paragraph brief.
4. Only then ask for an outline. Argue with the outline before you ask for a draft.
5. File the approved brief where you will see it when you reopen the work.

**Watch for.** Stop after the brief if you do not have time to make the thing today. A filed brief is already progress.

### Inbox pile to a weekly plan

**When to use.** Use at the start of a week, or when your task list has become a junk drawer.

1. Paste a raw list of open loops (email subjects, tasks, sticky notes). Redact first.
2. Ask for grouping: now, this week, waiting on someone, and drop or park.
3. Cap 'this week' at five items. If that feels impossible, run 'Scope trim' on your week.
4. For each of the five, write the next physical step (a verb you can do in one sitting).
5. Put waiting-on items in a separate list with a name and a follow-up date.

**Watch for.** The plan is the five items plus the follow-ups. Everything else is a parking lot, not a secret sixth priority.

### Notes to a source-checked summary

**When to use.** Use when you have an article, a report, or a long email thread you must rely on.

1. Paste the source text or your notes, not a request to 'look this up' if you need accuracy.
2. Run 'Reading notes that survive.' Keep the 'what this does not prove' line.
3. If you will share the summary, run 'Claim audit' on it.
4. Open at least one cited source or confirm the claims against the original text.
5. Only then write the version you will send, using 'Voice sample, then draft' if it goes to someone else.

**Watch for.** Do not skip the audit because the summary 'sounds right.'

### Meeting notes to tasks and a follow-up

**When to use.** Use the same day as the meeting, while your memory can still correct the notes.

1. Paste the raw notes. Do not tidy them first.
2. Run 'Notes to a decision log' and 'Extract owners without inventing them.'
3. Fill any UNASSIGNED or NO DATE items yourself, or with a quick question, before you send anything.
4. Run 'Meeting follow-up' to draft the sendable recap.
5. If you had hunches you should not broadcast, run 'Shared recap vs. private notes' and keep the private layer.

**Watch for.** Send the recap the same day. Put your own actions into your inbox immediately.

### A recurring process to a first SOP

**When to use.** Use when you are the only person who knows how something is done, including future-you.

1. Walk through the process once out loud or in notes. Sloppy is fine.
2. Run 'Process to SOP' and answer the sloppy-step questions it raises.
3. Do the task once with only the SOP in front of you. Note every stumble.
4. Update the SOP the same day. Add the 'if this goes wrong' section if it is still thin.
5. Run 'Should I automate this?' only after the SOP has survived a real use.

**Watch for.** An SOP you have not tried to follow is still a draft.

### The 'should I automate this?' path

**When to use.** Use when a task is annoying and a workflow tool is open in another tab.

1. Time the task once. Guessing that it is 'hours' is how fantasy automations get built.
2. Run 'Should I automate this?' honestly, including error cost.
3. If the answer is checklist or template, do that and stop.
4. If the answer is automate, run 'Workflow sketch' inside the tools you already have.
5. Run 'Failure modes for a flow,' then build the smallest version only.
6. Write the handoff note for future-you before you call it done.

**Watch for.** If you do not want to write the handoff note, the automation is not finished.

### Compare options and actually choose

**When to use.** Use when you are circling three options and calling it research.

1. Name the decision and the deadline for choosing, even if the deadline is this afternoon.
2. Run 'What would have to be true' for the option you secretly like.
3. Run 'Decision memo, one page' across the real options.
4. If the choice is reversible, run a small experiment instead of waiting for certainty.
5. Write the decision, the date, and the first next step in your notes. Then take the step.

**Watch for.** A memo you do not act on is still circling, just with better formatting.

### A weekly review you will still do when tired

**When to use.** Use once a week, same day if you can, with a 30-minute cap.

1. Set a timer. This workflow fails if it becomes an afternoon project.
2. Dump the week: calendar, task list, and anything lingering in your head.
3. Run 'Weekly review questions.' Accept the five-item cap.
4. Walk the 'Weekly maintenance' checklist and stop when the timer ends.
5. Write the one-sentence start for the next workday and close the laptop.

**Watch for.** A short review that happens beats a beautiful review you skip.

### Prep for a call in fifteen minutes

**When to use.** Use when the call is soon and your notes are thin.

1. Gather anything you already have: last email, last recap, a messy bullet list. Redact as needed.
2. Run 'Prep in fifteen minutes.' Do not ask for a perfect dossier.
3. Confirm the three facts yourself if they matter. Leave the rest marked unknown.
4. Pick two questions you will definitely ask. Put them at the top of your note.
5. After the call, run the meeting-notes workflow, even if it is only five minutes.

**Watch for.** Unknowns left visible are safer than a prep pack that invented a history.

### Turn a finished project into a reusable kit

**When to use.** Use after something worked, before you forget how.

1. Write down the outcome and the actual steps you took, not the steps you wish you had taken.
2. Pull out the prompts, checklists, or templates that helped. Name them.
3. Run 'Handoff to my future self' for the whole kit.
4. Drop the pieces into your command center or prompt library the same day.
5. Note one thing you would do differently, as a warning, not as a guilt trip.

**Watch for.** If this step keeps slipping, add it to the project definition of done.

## License

Personal-use license for the original buyer. You may use these materials in your own work, including work you personally deliver to a client. You may not resell, share, or republish the files, or upload them to a template marketplace. See LICENSE.txt in this folder for the full terms.

— Asdale Dynamics, LLC  ·  asdaledynamics.com  ·  2026
