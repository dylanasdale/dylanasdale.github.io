# KDP Self-Publishing Toolkit

By Asdale Dynamics, LLC · asdaledynamics.com

Two tools that handle the fiddly parts of publishing a book on Amazon KDP, plus a sample build so you can see the results before you start.

## What's inside

| Folder | What it is |
| --- | --- |
| `1-kdp-book-builder/` | A Python command-line tool. It turns a folder of Markdown chapters into a paperback interior PDF, a Kindle EPUB, a Kindle cover JPG, and a full paperback cover wrap sized to your page count, with bleed, spine, and barcode area included. It has 109 automated tests. |
| `2-kdp-listing-kit/` | A browser app with nothing to install. It checks your title and subtitle against KDP's limits, edits and cleans your description HTML against the 4,000-character limit, plans your seven keywords, keeps category notes, and walks you through KDP's AI-disclosure questions. |
| `3-sample-output/` | The files the builder made from its own sample book: a 6 x 9 in paperback interior, an EPUB, an ebook cover, a cover wrap, and a cover template. |

## Ten-minute start

### Prepare your listing (no install)

Double-click `2-kdp-listing-kit/open-me.html`. It opens in Chrome, Edge, Firefox, or Safari. Your work stays in your browser and nothing is uploaded.

### Build your book (needs Python 3.10 or newer)

```bash
cd 1-kdp-book-builder
python3 -m venv .venv
source .venv/bin/activate        # Windows: .\.venv\Scripts\Activate.ps1
python -m pip install -e .
kdp-book-builder build sample_book
```

Next, copy `sample_book/` to a new folder. Edit `book.yaml` with your title, author, trim size, and paper type, then swap in your own Markdown chapters. Run `kdp-book-builder build my-book`. The full guide is in `1-kdp-book-builder/README.md`.

## Checklist before you publish

1. Open the interior PDF and check the table of contents, page numbers, and chapter starts.
2. Upload the interior and cover wrap to KDP, then check every page in KDP's Print Previewer.
3. Upload the EPUB and check it in Kindle Previewer.
4. Copy your title, subtitle, description, and keywords from the listing kit into KDP.
5. Answer KDP's AI-content questions honestly. The listing kit's checklist helps you decide.
6. Order a printed proof before you click Publish.

## Good to know

- These tools make KDP-ready files, but KDP's current specs always win. Use KDP's previewer and order a printed proof.
- Both tools run on your own computer. They don't contact Amazon, and you don't need an account or an API key.
- The source code is MIT-licensed (see the `LICENSE` in each folder). What you're buying is the packaged, tested bundle, this guide, the no-install listing app, and the sample build.
- Questions? Email dylan.asdale@asdaledynamics.com.
