from kdp_book_builder.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
