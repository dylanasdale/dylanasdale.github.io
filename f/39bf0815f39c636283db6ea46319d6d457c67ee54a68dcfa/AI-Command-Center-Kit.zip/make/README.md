# Make starter blueprints

In Make, open Scenarios and use Import Blueprint, then select one of these JSON files.

1. `asdale-intake-to-brief.blueprint.json` — A custom webhook captures `title`, `notes`, and `priority`, normalizes them, and POSTs a JSON brief to a URL you choose.
2. `asdale-weekly-review-reminder.blueprint.json` — Same pattern for a weekly review reminder. After a successful import, you can replace the webhook trigger with Make's Scheduler if you want it to fire on a weekday without an incoming HTTP call.

**You must replace** `https://example.com/replace-with-your-endpoint` with a destination you control (another webhook, an email gateway, or a tool Make already supports). Leave the example URL in place only while you inspect the scenario; do not turn the scenario on until the URL is real.

If a blueprint fails to import because Make has changed a module name, rebuild it in five minutes from the setup guide: Custom webhook → Set variables → HTTP (or Email). The field mapping is in the JSON and in the guide.
