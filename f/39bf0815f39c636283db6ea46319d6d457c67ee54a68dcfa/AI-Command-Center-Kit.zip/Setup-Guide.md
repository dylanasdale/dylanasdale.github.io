# AI Command Center Kit — Setup Guide

Welcome. This guide gets the kit running in one sitting: a Notion-importable workspace, starter n8n workflows, and Make blueprints. Nothing here requires a paid plan to *import*. Some destinations (a live email send, a custom HTTP endpoint) need a place you already control.

If you also have the AI Manual Companion Pack, use its "Should I automate this?" path before you build anything larger than these starters.

## What is in the kit

- `Setup-Guide.pdf` — this guide, as a polished PDF
- `notion/` — Markdown pages and CSV databases
- `n8n/` — three importable workflow JSON files
- `make/` — two importable blueprint JSON files
- `LICENSE.txt` — the license for these files

## 1. Create the Notion workspace

1. In Notion, create a new private page named `AI Command Center`.
2. Open `Import` and bring in the Markdown pages from `notion/`, starting with `00-Start-Here.md` and `Home.md`, then the other `.md` files.
3. Import each `.csv` file the same way (`Import` → `CSV`). Notion will usually create a database or a table you can convert to a database.
4. Nest everything under the `AI Command Center` page. Pin `Home` and `Inbox`.
5. Open `Tasks` and `Projects` and replace or archive the example rows once you understand the shape.

Project names are plain text, not live relations, so the import does not break. You can create a relation later if you want.

### First twenty minutes

Follow `notion/00-Start-Here.md`: five captures in Inbox, two tasks with a real verb, one project, one prompt, and a 30-minute weekly review on your calendar.

## 2. Import the n8n workflows

You need an n8n instance you can log into (cloud or self-hosted). You do not need to add credentials for these starters.

1. In n8n, use the menu and choose **Import from File**.
2. Import `n8n/asdale-inbox-intake-webhook.json`. Open it. Click Test workflow or listen for a test webhook, then POST a JSON body such as:

```json
{ "title": "Follow up with Jordan", "notes": "About the Friday file", "priority": "high" }
```

You should get a structured task back. A missing title should return an error payload with HTTP 400.

3. Import `n8n/asdale-weekly-review-compiler.json`. Click **Test workflow**. The Set node has a sample list; the last node outputs Markdown you can paste into Weekly Review. Replace the sample list with your own `entries` when you are ready.
4. Import `n8n/asdale-daily-kickoff-prompt.json`. Run it manually first. It outputs a dated kickoff prompt. If you later activate the weekday schedule, edit the cron on the Schedule trigger so it matches *your* timezone, not just the default.
5. Activate only what you have tested. A live webhook should be treated like an open mailbox: do not share the URL casually, and do not post secrets to it.

## 3. Import the Make blueprints

1. In Make, go to Scenarios and choose **Import Blueprint**.
2. Import `make/asdale-intake-to-brief.blueprint.json`. A custom webhook collects `title`, `notes`, and `priority`, then an HTTP module posts a brief to a URL.
3. Import `make/asdale-weekly-review-reminder.blueprint.json` the same way.
4. **Replace** `https://example.com/replace-with-your-endpoint` in both scenarios with a destination you control. Do not turn a scenario on while the example URL is still there.
5. Run a once-off test with a sample webhook payload. Confirm the payload you wanted actually arrived.
6. If you want the weekly reminder to fire on a schedule instead of a webhook, add Make's Scheduler at the front after a successful import, then disable or remove the webhook trigger.

If a blueprint fails to import because Make has renamed a module, rebuild it in a few minutes: Custom webhook → Set variables → HTTP (or Email). The field names are in the JSON and in each blueprint's README.

## 4. Failure modes worth watching

- **Duplicates.** Hitting a webhook twice will create two tasks. If that would hurt, add a simple uniqueness rule later, or live with it and clean Inbox by hand for now.
- **Empty or messy input.** The n8n intake workflow rejects a missing title. Garbage in the notes field is still your problem — redact before you send.
- **Silent destinations.** A 200 from an HTTP module does not always mean the right record appeared. Check the destination once after every change.
- **Timezone drift.** Scheduled kickoffs that fire at the wrong hour are more annoying than useful. Set the timezone before you rely on the alarm.
- **Permissions.** Do not connect a work, school, or client account you do not have permission to automate.

## 5. A manual backup

If n8n or Make is down, you can still run the command center:

- Capture in Notion Inbox by hand.
- Run the weekly review page with a 30-minute timer.
- Copy the daily kickoff prompt from the setup (or from the Companion Pack, if you have it) and paste it into your assistant yourself.

The system is the habit plus the workspace. The automations are helpers.

## 6. When to stop building

Do not add a fourth automation until the first one has survived a real week and you have written a short handoff note for future-you (what it does, how you know it worked, how you know it broke).

— Asdale Dynamics, LLC  ·  asdaledynamics.com  ·  2026
