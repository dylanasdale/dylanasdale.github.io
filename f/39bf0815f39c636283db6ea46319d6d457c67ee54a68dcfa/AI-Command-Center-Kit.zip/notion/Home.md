# Home

This is the front door of the command center. After you import the CSV databases, you can mention or link them here (Inbox, Tasks, Projects, Weekly Review).

## Today

- What is the one thing that would make today a success?
- What am I waiting on from someone else?
- What should I not open today?

## This week (max five)

1.
2.
3.
4.
5.

## Parking lot

Things that are real and not this week:

-

## Links

- Inbox
- Tasks
- Projects
- Prompt Lab
- Automation Lab
- Weekly Review
- Decision Log
- Daily Operating System
