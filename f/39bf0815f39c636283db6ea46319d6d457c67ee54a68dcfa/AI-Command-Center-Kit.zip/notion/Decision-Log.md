# Decision log

A thin record so you can remember *why*, not just *what*.

| Date | Decision | Options considered | Why | Review on | Notes |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

Rules:

- One row per decision you would hate to relitigate from memory.
- "Why" can be three lines. If you need a manifesto, link out.
- Set a review date for decisions that should be revisited.
