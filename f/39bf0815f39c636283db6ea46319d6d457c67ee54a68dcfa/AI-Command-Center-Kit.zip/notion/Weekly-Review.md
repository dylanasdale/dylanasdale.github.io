# Weekly review

Cap this at 30 minutes. A short review that happens beats a beautiful one you skip.

Date:

## Dump

Calendar, task list, and anything lingering in your head:

## What moved

## What slipped, and why (one line, no speech)

## What I am avoiding

Next physical step, or a conscious drop:

## Next week (max five)

1.
2.
3.
4.
5.

## Waiting on others

| Who | What | Follow up on |
| --- | --- | --- |
|  |  |  |

## One system tweak

Keep this small (one prompt retired, one automation watched, one inbox path closed).

## Sentence for the next workday

After you import `Weekly-Reviews.csv`, log a short row there as well so reviews do not vanish into a long page.
