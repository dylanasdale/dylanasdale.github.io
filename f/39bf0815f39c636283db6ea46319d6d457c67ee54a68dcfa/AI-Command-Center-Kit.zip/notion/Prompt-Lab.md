# Prompt Lab

A small library beats a graveyard of one-off chats.

## How to add a prompt

1. Give it a name you would actually search for.
2. Write one line on the job it does.
3. List the inputs you must paste (and what to redact).
4. Paste the prompt with [BRACKETS] for the variable parts.
5. Add a one-line success test: how you know it worked.
6. Log it in `Prompts.csv`.

## If you also have the Companion Pack

You can lift any prompt from the AI Manual Companion Pack into this lab. Keep only the ones you use twice.

## Success test examples

- "I can send the email after one read-through."
- "The memo fits on one page and names a next step."
- "Owners that were missing are marked UNASSIGNED, not guessed."
