# AI Command Center — Start here

Welcome. This folder is a Notion-importable workspace from Asdale Dynamics.

## What you are setting up

A single command center with:

- A home page (this file, plus `Home.md`)
- An **Inbox** for raw captures
- **Projects** and **Tasks**
- A **Prompt Lab** and an **Automation Lab**
- A **Weekly Review** page and a small **Decision Log**
- A **Resources** list for links and files

Databases ship as CSV files so Notion can import them cleanly. Project names are plain text (not live relations) so you do not have to rebuild relations on day one. You can turn `Project` into a relation later if you want.

## Import, in order

1. In Notion, create a new empty private page called `AI Command Center`.
2. Open that page, use `Import` → `Markdown`, and import `Home.md`, `00-Start-Here.md`, `Daily-Operating-System.md`, `Weekly-Review.md`, `Automation-Lab.md`, `Prompt-Lab.md`, and `Decision-Log.md`.
3. Still in the same page (or as child pages), use `Import` → `CSV` for each file in this folder ending in `.csv`. Notion will create a table or database for each one.
4. Drag the imported pages and databases under `AI Command Center` so they live in one place.
5. Pin `Home` and `Inbox` somewhere you will actually see them.
6. Follow the setup guide PDF in the parent folder for n8n and Make, and for your first weekly review.

If a CSV imports as a plain table, open it and use Notion's option to convert it to a database.

## First twenty minutes

1. Drop five open loops into `Inbox`.
2. Promote two of them to `Tasks` with a next step that is a verb.
3. Put any multi-step effort into `Projects` with one next action.
4. Add one prompt you already like to `Prompts`.
5. Book a 30-minute weekly review on your calendar, same day each week.

— Asdale Dynamics, LLC  ·  2026
