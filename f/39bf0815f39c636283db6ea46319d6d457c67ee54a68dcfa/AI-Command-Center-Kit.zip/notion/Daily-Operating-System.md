# Daily operating system

A light daily rhythm. Skip it on days that are already too heavy; do not "catch up" by doing it twice.

## Start (5–10 minutes)

1. Look at Home, then Inbox, then today's Tasks.
2. Pick one start-here task and write the first verb.
3. If an assistant will help, state the job and what 'done' looks like before you paste anything.
4. Redact before you paste.

## During the day

- Capture into Inbox only. Do not open a second inbox "just for now."
- When a task finishes, mark it done immediately so it stops posing as live work.
- If something new is truly urgent, it must bump one of the five weekly items — not join them in secret.

## Shutdown (5 minutes)

1. Park the active task with a next starting step written down.
2. Sweep stray notes into Inbox.
3. Write one sentence for tomorrow morning.
4. Close the tools.

The Command Center is working if shutdown is boring and the next morning is obvious.
