# Notion files in this folder

Import these from inside a single Notion page called AI Command Center. Full steps are in `00-Start-Here.md` and in the setup guide PDF.

Markdown pages: `00-Start-Here.md`, `Home.md`, `Daily-Operating-System.md`, `Weekly-Review.md`, `Automation-Lab.md`, `Prompt-Lab.md`, `Decision-Log.md`.

CSV databases: `Inbox.csv`, `Projects.csv`, `Tasks.csv`, `Prompts.csv`, `Automations.csv`, `Weekly-Reviews.csv`, `Resources.csv`.

Example rows are included so you can see the intended shape. Replace or archive them once your own data is in.
