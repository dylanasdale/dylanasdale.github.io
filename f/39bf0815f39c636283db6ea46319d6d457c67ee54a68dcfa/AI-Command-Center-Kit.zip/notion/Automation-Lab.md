# Automation Lab

Use this page to design small automations *after* a process has survived as a checklist.

## Gate

- [ ] I have done this by hand enough times to know the happy path.
- [ ] I have a checklist or SOP.
- [ ] The trigger is unambiguous.
- [ ] Failure can be loud.
- [ ] I have a manual backup.

## Sketch

**Name:**
**Trigger:**
**Input:**
**Output:**
**Tool (n8n, Make, or other):**
**Failure mode I must watch:**
**Manual backup:**

## Starter workflows in this kit

See the `n8n` and `make` folders, and the setup guide PDF:

1. Inbox intake webhook — drop a title and notes, get a structured task back.
2. Weekly review compiler — turn a simple list into a review outline.
3. Daily kickoff — a dated start-of-day prompt you can paste into an assistant.
4. Make: intake to a brief, plus a weekly reminder sketch.

Log live automations in `Automations.csv`.
