# n8n starter workflows

Import each JSON file in n8n: menu (⋯) → Import from File. Leave them inactive until you have read the setup guide.

1. `asdale-inbox-intake-webhook.json` — POST JSON `{ "title", "notes", "priority" }` to `/webhook/asdale-intake` (or the test URL n8n shows). Returns a structured task or a 400 if title is missing. No credentials required.
2. `asdale-weekly-review-compiler.json` — Click Test workflow. The Set node holds a sample list; replace it with your own, or pass an `entries` array. The last node outputs Markdown you can paste into Weekly Review.
3. `asdale-daily-kickoff-prompt.json` — Manual run, plus an optional weekday 8:30 schedule in America/Indiana/Indianapolis context (adjust the cron in the trigger to your timezone). Outputs a prompt to paste into your assistant.

After import, open each workflow once and use n8n's Test step to confirm the output panel shows JSON. Then, and only then, activate the webhook or schedule.
